﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drawing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Rectangle rect = new Rectangle(20, 20, 100, 100);
            // Create two Pen objects, one red and one black
            Pen redPen = new Pen(Color.Red, 3);
            Pen blackPen = Pens.Black;
            // Draw rectangle and circle 
            g.DrawRectangle(redPen, rect);
            g.FillEllipse(Brushes.Green, rect);
            // Draw circles on the line
            g.DrawLine(blackPen, 0, 250, this.Width, 250);
            g.FillEllipse(Brushes.Blue, 70, 220, 30, 30);
            g.FillEllipse(Brushes.SkyBlue, 100, 210, 40, 40);
            g.FillEllipse(Brushes.Green, 140, 200, 50, 50);
            g.FillEllipse(Brushes.Yellow, 190, 190, 60, 60);
            g.FillEllipse(Brushes.Violet, 250, 180, 70, 70);
            g.FillEllipse(Brushes.Red, 320, 170, 80, 80);
            // Dispose of objects
            // blackPen.Dispose();
            redPen.Dispose();
            g.Dispose();
        }
    }
}
