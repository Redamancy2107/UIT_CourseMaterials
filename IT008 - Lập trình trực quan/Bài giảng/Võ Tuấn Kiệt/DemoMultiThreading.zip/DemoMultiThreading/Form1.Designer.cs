﻿namespace DemoMultiThreading
{
  partial class mainForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.numberLabel = new System.Windows.Forms.Label();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.singleRadioButton = new System.Windows.Forms.RadioButton();
      this.multiRadioButton = new System.Windows.Forms.RadioButton();
      this.startButton = new System.Windows.Forms.Button();
      this.exitButton = new System.Windows.Forms.Button();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // numberLabel
      // 
      this.numberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.numberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.numberLabel.Location = new System.Drawing.Point(106, 35);
      this.numberLabel.Name = "numberLabel";
      this.numberLabel.Size = new System.Drawing.Size(122, 52);
      this.numberLabel.TabIndex = 0;
      this.numberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.multiRadioButton);
      this.groupBox1.Controls.Add(this.singleRadioButton);
      this.groupBox1.Location = new System.Drawing.Point(56, 127);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(236, 52);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Mode";
      // 
      // singleRadioButton
      // 
      this.singleRadioButton.AutoSize = true;
      this.singleRadioButton.Checked = true;
      this.singleRadioButton.Location = new System.Drawing.Point(16, 20);
      this.singleRadioButton.Name = "singleRadioButton";
      this.singleRadioButton.Size = new System.Drawing.Size(91, 17);
      this.singleRadioButton.TabIndex = 0;
      this.singleRadioButton.TabStop = true;
      this.singleRadioButton.Text = "Single Thread";
      this.singleRadioButton.UseVisualStyleBackColor = true;
      // 
      // multiRadioButton
      // 
      this.multiRadioButton.AutoSize = true;
      this.multiRadioButton.Location = new System.Drawing.Point(137, 20);
      this.multiRadioButton.Name = "multiRadioButton";
      this.multiRadioButton.Size = new System.Drawing.Size(84, 17);
      this.multiRadioButton.TabIndex = 1;
      this.multiRadioButton.Text = "Multi Thread";
      this.multiRadioButton.UseVisualStyleBackColor = true;
      // 
      // startButton
      // 
      this.startButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.startButton.Location = new System.Drawing.Point(56, 197);
      this.startButton.Name = "startButton";
      this.startButton.Size = new System.Drawing.Size(75, 39);
      this.startButton.TabIndex = 2;
      this.startButton.Text = "Start";
      this.startButton.UseVisualStyleBackColor = true;
      this.startButton.Click += new System.EventHandler(this.startButton_Click);
      // 
      // exitButton
      // 
      this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.exitButton.Location = new System.Drawing.Point(217, 197);
      this.exitButton.Name = "exitButton";
      this.exitButton.Size = new System.Drawing.Size(75, 39);
      this.exitButton.TabIndex = 3;
      this.exitButton.Text = "Exit";
      this.exitButton.UseVisualStyleBackColor = true;
      this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
      // 
      // mainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(358, 266);
      this.Controls.Add(this.exitButton);
      this.Controls.Add(this.startButton);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.numberLabel);
      this.Name = "mainForm";
      this.Text = "Multithreading Demo";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Label numberLabel;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.RadioButton multiRadioButton;
    private System.Windows.Forms.RadioButton singleRadioButton;
    private System.Windows.Forms.Button startButton;
    private System.Windows.Forms.Button exitButton;
  }
}

