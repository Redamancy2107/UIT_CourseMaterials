﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoMultiThreading
{
  public partial class mainForm : Form
  {
    public mainForm()
    {
      InitializeComponent();
    }

    private void exitButton_Click(object sender, EventArgs e)
    {
      Application.Exit();
    }

    private void startButton_Click(object sender, EventArgs e)
    {
      const int n = 1000;
      if (singleRadioButton.Checked)
      {
        for (int i = 0; i < n; i++)
        {
          numberLabel.Text = i.ToString();
          Thread.Sleep(1); // simulate time-consumed process
        }
      }
      else
      {
        Action task = new Action(()=>
        {
          for (int i = 0; i < n; i++)
          {
            this.Invoke(new Action(()=> {
              numberLabel.Text = i.ToString();
            }));
            Thread.Sleep(1); // simulate time-consumed process
          }
        });
        Task.Run(task);

      }
    }
  }
}
