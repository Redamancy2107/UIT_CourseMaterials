﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game
{
    public partial class mainForm : Form
    {
        private int r = 1;
        private int cx, cy;
        private int n = 2;
        private int count = 0;
        public mainForm()
        {
            InitializeComponent();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            r = ClientSize.Height / 16;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            n++;
            if (n>15)
            {
                timer1.Enabled = false;
                MessageBox.Show("Ban da click trung " + count.ToString() + " lan");
                return;
            }
            Invalidate();   
        }

        private void mainForm_MouseClick(object sender, MouseEventArgs e)
        {
            if (Math.Sqrt((e.X - cx) * (e.X - cx) + (e.Y - cy) * (e.Y - cy)) <= r)
                count++;
        }

        private void mainForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Random rnd = new Random();
            for (int i = 0; i < n; i++)
            {
                int x = rnd.Next(r, ClientSize.Width - r + 1);
                int y = rnd.Next(r, ClientSize.Height - r + 1);
                g.FillEllipse(Brushes.Blue, x - r, y - r, 2 * r, 2 * r);
            }
            cx = rnd.Next(r, ClientSize.Width - r + 1);
            cy = rnd.Next(r, ClientSize.Height - r + 1);
            g.FillEllipse(Brushes.Red, cx - r, cy - r, 2 * r, 2 * r);
        }
    }
}
