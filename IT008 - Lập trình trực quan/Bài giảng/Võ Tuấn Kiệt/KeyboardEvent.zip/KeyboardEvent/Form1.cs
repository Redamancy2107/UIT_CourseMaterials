﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KeyboardEvent
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            keyPressedLabel.Text = $"Key pressed: {e.KeyChar}";
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            String altStatus = (e.Alt) ? "Yes" : "No";
            String shiftStatus = (e.Shift) ? "Yes" : "No";
            String ctrlStatus = (e.Control) ? "Yes" : "No";
            moreInfoLabel.Text = $"Alt: {altStatus}\nShift: {shiftStatus}\nControl: {ctrlStatus}\nKeycode: {e.KeyCode}\nKeyData: {e.KeyData}\nKeyValue: {e.KeyValue}";
        }

     
    }
}
